var square= (num)
=num*num;
var result= square(5);
console.log(result);