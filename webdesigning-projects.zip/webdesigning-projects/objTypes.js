//literal object
let player1 = 
{
    name: "hadee",
    team: "India"
}
//empty object
let player2 ={}
player2.name= "De Bruyne",
player2.team= "Belgium"
//object with new keyword
let player3= new Object();
player3.name= "Garnacho",
player3.team= "Argentina"
//print all objects
console.log("Youngest player is ", player1.name,". From ",player1.team);
console.log("favourite player is ", player2.name,". From ",player2.team);
console.log("Emerging  player is ", player3.name,". From ",player3.team);