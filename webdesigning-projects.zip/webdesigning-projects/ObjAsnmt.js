let pet={
    type: "Dog",
    Fname: "bucky",
    legs:  4,
    colour:"Brown in white",
    food: {
        type: "pedigri",
    }
}
for (i in pet)
{
    console.log(pet [i]);
}
for (i in pet.food)
{
    console.log(pet.food[i])
}
