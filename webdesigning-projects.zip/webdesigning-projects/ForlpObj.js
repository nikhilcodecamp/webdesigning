let char =
{
    fname: "hadee",
    age: 19,
    gender: "male",
    place: "Kerala",
    CarComp: "BMW"
}
for (i in char)
{
    console.log(char[i]);
}