var i=1;
do{
    console.log(i);
    i++;
}
while(i<=5);