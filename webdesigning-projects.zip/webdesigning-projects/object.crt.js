//create an object
let person =
{
    name: "Hadee",
    age: 19,
    jersyNumber: 17,
};
console.log(person.name);
console.log(person.age);
console.log(person.jersyNumber);
