let players = ['Ronaldo','Messi','Neymar','De Bruyne','Ozil'];
console.log("array is:",players);
players.push("Lewandoski");
console.log("after push: ",players);
players.pop(1);
console.log("array after pop: ",players);