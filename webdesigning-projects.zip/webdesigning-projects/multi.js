var calculateArea= function(width, height)
{
    return width*height;
};
var area= calculateArea(5,3);
console.log(area);