let nos= [1, 2, 3, 4, 5, 6, 7];
console.log(" the initial array:",nos);
console.log("length of the array: ",nos.length);
console.log("first number is:",nos[0]);
console.log("the last no. is:",nos[nos.length])
